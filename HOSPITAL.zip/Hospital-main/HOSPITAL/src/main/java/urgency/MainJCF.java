package urgency;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class MainJCF {
    private static final String PATIENT_FILE = "pacientes";

    public static void main(String[] args) {
        List<Paciente> pacientes = cargarPacientes();
        if (pacientes.isEmpty()) {
            System.err.println("No hay pacientes disponibles para procesar.");
            return;
        }

        PriorityQueue<Paciente> cola = new PriorityQueue<>(pacientes);
        System.out.println("Orden de atención (Java Collection Framework):");
        while (!cola.isEmpty()) {
            System.out.println(cola.poll());
        }
    }

    private static List<Paciente> cargarPacientes() {
        List<Paciente> pacientes = new ArrayList<>();
        try (BufferedReader lector = abrirArchivoDePacientes()) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                Paciente paciente = crearPaciente(linea);
                if (paciente != null) {
                    pacientes.add(paciente);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
        return pacientes;
    }

    private static Paciente crearPaciente(String linea) {
        String[] partes = linea.split(",");
        if (partes.length != 3) {
            return null;
        }
        String nombre = partes[0].trim();
        String sintoma = partes[1].trim();
        String codigo = partes[2].trim();
        return new Paciente(nombre, sintoma, codigo);
    }

    private static BufferedReader abrirArchivoDePacientes() throws IOException {
        Path path = Paths.get(PATIENT_FILE);
        if (!Files.exists(path)) {
            path = Paths.get("..", PATIENT_FILE);
        }
        if (!Files.exists(path)) {
            path = Paths.get("..", "..", PATIENT_FILE);
        }
        if (!Files.exists(path)) {
            path = Paths.get("..", "..", "..", PATIENT_FILE);
        }
        if (!Files.exists(path)) {
            throw new IOException("No se encontró el archivo '" + PATIENT_FILE + "'.");
        }
        return Files.newBufferedReader(path, StandardCharsets.UTF_8);
    }
}
