package urgency;

import java.util.Vector;

public class VectorHeap<E extends Comparable<? super E>> implements PriorityQueue<E> {

    protected Vector<E> heap;

    public VectorHeap() {
        heap = new Vector<E>();
    }

    public VectorHeap(Vector<E> initialValues) {
        heap = new Vector<E>(initialValues.size());
        for (E value : initialValues) {
            add(value);
        }
    }

    protected static int parent(int index) {
        return (index - 1) / 2;
    }

    protected static int left(int index) {
        return 2 * index + 1;
    }

    protected static int right(int index) {
        return 2 * index + 2;
    }

    protected void percolateUp(int index) {
        int parent = parent(index);
        E value = heap.get(index);
        while (index > 0 && value.compareTo(heap.get(parent)) < 0) {
            heap.set(index, heap.get(parent));
            index = parent;
            parent = parent(index);
        }
        heap.set(index, value);
    }

    @Override
    public void add(E value) {
        heap.add(value);
        percolateUp(heap.size() - 1);
    }

    protected void pushDownRoot(int root) {
        int heapSize = heap.size();
        E value = heap.get(root);
        while (root < heapSize) {
            int childPos = left(root);
            if (childPos < heapSize) {
                int rightPos = right(root);
                if (rightPos < heapSize && heap.get(rightPos).compareTo(heap.get(childPos)) < 0) {
                    childPos = rightPos;
                }
                if (heap.get(childPos).compareTo(value) < 0) {
                    heap.set(root, heap.get(childPos));
                    root = childPos;
                } else {
                    heap.set(root, value);
                    return;
                }
            } else {
                heap.set(root, value);
                return;
            }
        }
    }

    @Override
    public E remove() {
        if (isEmpty()) {
            return null;
        }
        E first = getFirst();
        int lastIndex = heap.size() - 1;
        heap.set(0, heap.get(lastIndex));
        heap.setSize(lastIndex);
        if (!isEmpty()) {
            pushDownRoot(0);
        }
        return first;
    }

    @Override
    public E getFirst() {
        return isEmpty() ? null : heap.get(0);
    }

    @Override
    public boolean isEmpty() {
        return heap.isEmpty();
    }

    @Override
    public int size() {
        return heap.size();
    }

    @Override
    public void clear() {
        heap.clear();
    }
}
