package urgency;

/**
 * Interfaz para una cola de prioridad basada en elementos comparables.
 * Los elementos de menor prioridad numérica se procesan primero.
 */
public interface PriorityQueue<E extends Comparable<? super E>> {
    E getFirst();
    E remove();
    void add(E value);
    boolean isEmpty();
    int size();
    void clear();
}
