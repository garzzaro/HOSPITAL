package urgency;

import java.util.HashMap;
import java.util.Map;

public class Paciente implements Comparable<Paciente> {
    private static final Map<String, Integer> PRIORITY_ORDER = new HashMap<String, Integer>();
    static {
        PRIORITY_ORDER.put("A", 1);
        PRIORITY_ORDER.put("B", 2);
        PRIORITY_ORDER.put("C", 3);
        PRIORITY_ORDER.put("D", 4);
        PRIORITY_ORDER.put("E", 5);
    }

    private final String nombre;
    private final String sintoma;
    private final String codigoEmergencia;

    public Paciente(String nombre, String sintoma, String codigoEmergencia) {
        this.nombre = nombre;
        this.sintoma = sintoma;
        this.codigoEmergencia = codigoEmergencia.toUpperCase();
    }

    public String getNombre() {
        return nombre;
    }

    public String getSintoma() {
        return sintoma;
    }

    public String getCodigoEmergencia() {
        return codigoEmergencia;
    }

    @Override
    public int compareTo(Paciente otro) {
        Integer prioridadActual = PRIORITY_ORDER.getOrDefault(codigoEmergencia, Integer.MAX_VALUE);
        Integer prioridadOtro = PRIORITY_ORDER.getOrDefault(otro.codigoEmergencia, Integer.MAX_VALUE);
        int comparacion = prioridadActual.compareTo(prioridadOtro);
        if (comparacion != 0) {
            return comparacion;
        }
        return nombre.compareToIgnoreCase(otro.nombre);
    }

    @Override
    public String toString() {
        return nombre + ", " + sintoma + ", " + codigoEmergencia;
    }
}
