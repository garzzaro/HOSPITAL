package urgency;

public class VectorHeapTest {

    public static void main(String[] args) {
        testAddAndRemove();
        System.out.println("All VectorHeap tests passed.");
    }

    public static void testAddAndRemove() {
        VectorHeap<String> heap = new VectorHeap<>();
        
        heap.add("C");
        heap.add("A");
        heap.add("B");
        
        assertEqual("A", heap.remove());
        assertEqual("B", heap.remove());
        assertEqual("C", heap.remove());
        if (!heap.isEmpty()) {
            throw new AssertionError("Heap should be empty");
        }
    }

    private static void assertEqual(String expected, String actual) {
        if (!expected.equals(actual)) {
            throw new AssertionError("Expected " + expected + " but got " + actual);
        }
    }
}
